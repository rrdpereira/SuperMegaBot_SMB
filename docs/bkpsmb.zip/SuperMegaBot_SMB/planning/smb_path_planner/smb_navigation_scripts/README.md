## smb_navigation_scripts
This package contains utility scripts for testing.

### Installation
```
$ pip install numpy matplotlib scipy
```
