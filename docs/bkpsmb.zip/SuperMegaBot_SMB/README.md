# SuperMegaBot_SMB
ETH 4 wheel Super Mega Bot (SMB) applications [https://ethz-robotx.github.io/SuperMegaBot/]

https://ethz-robotx.github.io/SuperMegaBot/core-software/installation_core.html

https://ethz-robotx.github.io/SuperMegaBot/core-software/HowToRunSoftware.html

https://unlimited.ethz.ch/display/ROBOTX/SuperMegaBot

https://github.com/ethz-asl/eth_supermegabot

https://github.com/cra-ros-pkg/robot_localization/blob/noetic-devel/params/ekf_template.yaml